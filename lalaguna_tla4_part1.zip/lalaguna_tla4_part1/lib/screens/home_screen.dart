import 'package:flutter/material.dart';

class HomeScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Home')),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            ElevatedButton(
              child: Text('About'),
              onPressed: () => Navigator.pushNamed(context, '/about'),
            ),
            ElevatedButton(
              child: Text('Settings'),
              onPressed: () => Navigator.pushNamed(context, '/settings'),
            ),
            ElevatedButton(
              child: Text('Profile'),
              onPressed: () => Navigator.pushNamed(context, '/profile'),
            ),
            ElevatedButton(
              child: Text('Contact'),
              onPressed: () => Navigator.pushNamed(context, '/contact'),
            ),
          ],
        ),
      ),
    );
  }
}
